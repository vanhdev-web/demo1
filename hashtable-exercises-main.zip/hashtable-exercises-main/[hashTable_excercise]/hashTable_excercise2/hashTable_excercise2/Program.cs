﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace hashTable_excercise2
{
    class SpellChecker
    {
        private Hashtable dictionary;

        public SpellChecker()
        {
            dictionary = new Hashtable();
            InitializeDictionary();
        }

        private void InitializeDictionary()
        {
            string[] commonWords = {
            "the", "be", "to", "of", "and", "a", "in", "that", "have",
            "it", "for", "not", "on", "with", "he", "she", "as", "you",
            "do", "at", "this", "but", "his", "by", "from", "they",
            "we", "say", "her", "or", "an", "will", "my", "one",
            "all", "would", "there", "their", "what", "so", "up",
            "out", "if", "about", "who", "get", "which", "go", "me"
        };

            foreach (string word in commonWords)
            {
                dictionary.Add(word.ToLower(), true);
            }
        }

        public List<string> CheckSpelling(string filename)
        {
            List<string> misspelledWords = new List<string>();

            try
            {
                // Ensure the file exists
                if (!File.Exists(filename))
                {
                    Console.WriteLine($"Error: File not found - {filename}");
                    return misspelledWords;
                }

                string text = File.ReadAllText(filename);
                string[] words = text.Split(new[] { ' ', '.', ',', '!', '?', '\n', '\r', '\t', ';', ':', '(', ')' },
                                          StringSplitOptions.RemoveEmptyEntries);

                foreach (string word in words)
                {
                    string cleanWord = word.Trim().ToLower();
                    if (!string.IsNullOrEmpty(cleanWord) && !dictionary.ContainsKey(cleanWord))
                    {
                        misspelledWords.Add(word);
                    }
                }
            }
            catch (UnauthorizedAccessException)
            {
                Console.WriteLine($"Error: Access denied. Make sure you have permission to access the file.");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Error reading file: {ex.Message}");
            }

            return misspelledWords;
        }

        static void Main(string[] args)
        {
            SpellChecker checker = new SpellChecker();

            // Specify the path to your text file on the E: drive
            string filePath = @"E:\text.txt";

            // Check if the file exists before proceeding
            if (!File.Exists(filePath))
            {
                Console.WriteLine($"Error: File not found at {filePath}");
                Console.WriteLine("Please ensure your text file exists in the E: drive.");
                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
                return;
            }

            // Check spelling
            List<string> misspelledWords = checker.CheckSpelling(filePath);

            if (misspelledWords.Count == 0)
            {
                Console.WriteLine("No spelling errors found!");
            }
            else
            {
                Console.WriteLine("\nPossible spelling errors:");
                foreach (string word in misspelledWords)
                {
                    Console.WriteLine($"- {word}");
                }
            }

            Console.WriteLine("\nPress any key to exit...");
            Console.ReadKey();
        }
    }
}