﻿using System;
using System.Windows.Forms;
using System.IO;
using System.Collections;

namespace ArrayListGlossary
{
    // HashEntry to store key-value pairs and status
    public class HashEntry
    {
        public string Key { get; set; }
        public string Value { get; set; }
        public bool IsOccupied { get; set; }
        public bool IsDeleted { get; set; }

        public HashEntry()
        {
            IsOccupied = false;
            IsDeleted = false;
        }
    }

    // Modified Hash class using ArrayList
    public class ArrayListHash
    {
        private ArrayList table;
        private int size;
        private int count;
        private readonly double loadFactor = 0.75;
        public enum CollisionStrategy { LinearProbing, DoubleHashing }
        private CollisionStrategy currentStrategy;

        public ArrayListHash(int initialSize, CollisionStrategy strategy)
        {
            size = GetNextPrime(initialSize);
            table = new ArrayList(size);
            // Initialize ArrayList with empty HashEntry objects
            for (int i = 0; i < size; i++)
            {
                table.Add(new HashEntry());
            }
            count = 0;
            currentStrategy = strategy;
        }

        // Primary hash function using polynomial accumulation
        private int Hash1(string key)
        {
            int hash = 0;
            for (int i = 0; i < key.Length; i++)
            {
                hash = (hash * 31 + key[i]) % size;
            }
            return Math.Abs(hash);
        }

        // Secondary hash function for double hashing
        private int Hash2(string key)
        {
            int hash = 0;
            for (int i = 0; i < key.Length; i++)
            {
                hash = (hash * 37 + key[i]) % size;
            }
            return Math.Abs(hash * 2 + 1); // Ensure result is odd
        }

        private int GetNextPrime(int n)
        {
            while (!IsPrime(n)) n++;
            return n;
        }

        private bool IsPrime(int n)
        {
            if (n < 2) return false;
            for (int i = 2; i <= Math.Sqrt(n); i++)
            {
                if (n % i == 0) return false;
            }
            return true;
        }

        private void Resize()
        {
            ArrayList oldTable = table;
            size = GetNextPrime(size * 2);
            table = new ArrayList(size);

            // Initialize new ArrayList with empty HashEntry objects
            for (int i = 0; i < size; i++)
            {
                table.Add(new HashEntry());
            }
            count = 0;

            // Reinsert all existing entries
            foreach (HashEntry entry in oldTable)
            {
                if (entry.IsOccupied && !entry.IsDeleted)
                {
                    Add(entry.Key, entry.Value);
                }
            }
        }

        public void Add(string key, string value)
        {
            if ((double)count / size >= loadFactor)
            {
                Resize();
            }

            int index = Hash1(key);
            int step = (currentStrategy == CollisionStrategy.LinearProbing) ? 1 : Hash2(key);

            while (((HashEntry)table[index]).IsOccupied && !((HashEntry)table[index]).IsDeleted)
            {
                if (((HashEntry)table[index]).Key == key)
                {
                    ((HashEntry)table[index]).Value = value; // Update existing key
                    return;
                }
                index = (index + step) % size;
            }

            HashEntry newEntry = (HashEntry)table[index];
            newEntry.Key = key;
            newEntry.Value = value;
            newEntry.IsOccupied = true;
            newEntry.IsDeleted = false;
            count++;
        }

        public string Get(string key)
        {
            int index = Hash1(key);
            int step = (currentStrategy == CollisionStrategy.LinearProbing) ? 1 : Hash2(key);
            int startIndex = index;

            do
            {
                HashEntry entry = (HashEntry)table[index];
                if (!entry.IsOccupied) return null;
                if (entry.IsOccupied && !entry.IsDeleted && entry.Key == key)
                {
                    return entry.Value;
                }
                index = (index + step) % size;
            } while (index != startIndex);

            return null;
        }

        public string[] GetAllKeys()
        {
            var keys = new System.Collections.Generic.List<string>();
            foreach (HashEntry entry in table)
            {
                if (entry.IsOccupied && !entry.IsDeleted)
                {
                    keys.Add(entry.Key);
                }
            }
            return keys.ToArray();
        }
    }

        public class Form1 : Form
        {
        
            private ListBox lstWords;
            private TextBox txtDefinition;
            private Label lblWords;
            private Label lblDefinition;
            private RadioButton rbLinearProbing;
            private RadioButton rbDoubleHashing;
            private Button btnReload;
            private Label lblStatus;
            private ArrayListHash glossary;

            public Form1()
            {
                InitializeComponent();
                InitializeHash(ArrayListHash.CollisionStrategy.LinearProbing);
            }

            private void InitializeHash(ArrayListHash.CollisionStrategy strategy)
            {
                glossary = new ArrayListHash(100, strategy);
                LoadGlossary();
                DisplayWords();
            }

        private void InitializeComponent()
        {
            this.lstWords = new ListBox();
            this.txtDefinition = new TextBox();
            this.lblWords = new Label();
            this.lblDefinition = new Label();
            this.rbLinearProbing = new RadioButton();
            this.rbDoubleHashing = new RadioButton();
            this.btnReload = new Button();
            this.lblStatus = new Label();

            // Words Label
            this.lblWords.AutoSize = true;
            this.lblWords.Location = new System.Drawing.Point(12, 9);
            this.lblWords.Size = new System.Drawing.Size(40, 13);
            this.lblWords.Text = "Words";

            // Words ListBox
            this.lstWords.Location = new System.Drawing.Point(12, 25);
            this.lstWords.Size = new System.Drawing.Size(120, 200);
            this.lstWords.SelectedIndexChanged += new EventHandler(lstWords_SelectedIndexChanged);

            // Definition Label
            this.lblDefinition.AutoSize = true;
            this.lblDefinition.Location = new System.Drawing.Point(12, 235);
            this.lblDefinition.Size = new System.Drawing.Size(51, 13);
            this.lblDefinition.Text = "Definition";

            // Definition TextBox
            this.txtDefinition.Location = new System.Drawing.Point(12, 251);
            this.txtDefinition.Multiline = true;
            this.txtDefinition.Size = new System.Drawing.Size(400, 60);
            this.txtDefinition.ReadOnly = true;

            // Radio Buttons
            this.rbLinearProbing.Location = new System.Drawing.Point(150, 25);
            this.rbLinearProbing.Text = "Linear Probing";
            this.rbLinearProbing.Checked = true;
            this.rbLinearProbing.AutoSize = true;

            this.rbDoubleHashing.Location = new System.Drawing.Point(150, 48);
            this.rbDoubleHashing.Text = "Double Hashing";
            this.rbDoubleHashing.AutoSize = true;

            // Reload Button
            this.btnReload.Location = new System.Drawing.Point(150, 71);
            this.btnReload.Text = "Reload";
            this.btnReload.AutoSize = true;
            this.btnReload.Click += new EventHandler(btnReload_Click);

            // Status Label
            this.lblStatus.Location = new System.Drawing.Point(150, 100);
            this.lblStatus.Size = new System.Drawing.Size(250, 40);
            this.lblStatus.AutoSize = true;

            // Form
            this.ClientSize = new System.Drawing.Size(424, 321);
            this.Controls.AddRange(new Control[] {
                this.lblWords,
                this.lstWords,
                this.lblDefinition,
                this.txtDefinition,
                this.rbLinearProbing,
                this.rbDoubleHashing,
                this.btnReload,
                this.lblStatus
            });
            this.Text = "Glossary";
        }

        private void LoadGlossary()
        {
            try
            {
                using (StreamReader inFile = File.OpenText("e:\\words.txt"))
                {
                    string line;
                    while ((line = inFile.ReadLine()) != null)
                    {
                        string[] words = line.Split(',');
                        if (words.Length >= 2)
                        {
                            glossary.Add(words[0].Trim(), words[1].Trim());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading glossary: " + ex.Message);
            }
        }

        private void DisplayWords()
        {
            lstWords.Items.Clear();
            string[] words = glossary.GetAllKeys();
            lstWords.Items.AddRange(words);

            if (lstWords.Items.Count > 0)
                lstWords.SelectedIndex = 0;
        }

        private void lstWords_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (lstWords.SelectedItem != null)
            {
                string word = lstWords.SelectedItem.ToString();
                txtDefinition.Text = glossary.Get(word) ?? "Definition not found";
            }
        }

        private void btnReload_Click(object sender, EventArgs e)
        {
           ArrayListHash.CollisionStrategy strategy = rbLinearProbing.Checked ?
               ArrayListHash.CollisionStrategy.LinearProbing :
               ArrayListHash.CollisionStrategy.DoubleHashing;

            InitializeHash(strategy);
        }

        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.Run(new Form1());
        }
    }
}