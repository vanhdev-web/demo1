﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dsa_dictionary_ex2
{
    internal static class Program
    {
        public class CustomSortedList<TKey, TValue> : IEnumerable<KeyValuePair<TKey, TValue>>       //here the custom list
        where TKey : IComparable<TKey>
        {
            private TKey[] keys;
            private TValue[] values;
            private int count;
            private readonly int defaultCapacity = 4;

            public CustomSortedList()
            {
                keys = new TKey[defaultCapacity];
                values = new TValue[defaultCapacity];
                count = 0;
            }

            public int Count => count;

            public void Add(TKey key, TValue value)
            {
                if (key == null)
                    throw new ArgumentNullException(nameof(key));

                // Find insertion point
                int insertIndex = 0;
                while (insertIndex < count && keys[insertIndex].CompareTo(key) < 0)
                {
                    insertIndex++;
                }

                // Check if key already exists
                if (insertIndex < count && keys[insertIndex].CompareTo(key) == 0)
                    throw new ArgumentException("An item with the same key already exists.");

                // Resize if necessary
                if (count == keys.Length)
                {
                    Array.Resize(ref keys, keys.Length * 2);
                    Array.Resize(ref values, values.Length * 2);
                }

                // Shift elements to make room for new item
                for (int i = count; i > insertIndex; i--)
                {
                    keys[i] = keys[i - 1];
                    values[i] = values[i - 1];
                }

                // Insert new item
                keys[insertIndex] = key;
                values[insertIndex] = value;
                count++;
            }

            public void Clear()
            {
                keys = new TKey[defaultCapacity];
                values = new TValue[defaultCapacity];
                count = 0;
            }

            public bool ContainsKey(TKey key)
            {
                return IndexOfKey(key) >= 0;
            }

            public bool ContainsValue(TValue value)
            {
                for (int i = 0; i < count; i++)
                {
                    if (value == null)
                    {
                        if (values[i] == null) return true;
                    }
                    else if (values[i] != null && values[i].Equals(value))
                    {
                        return true;
                    }
                }
                return false;
            }

            public TValue this[TKey key]
            {
                get
                {
                    int index = IndexOfKey(key);
                    if (index >= 0)
                        return values[index];
                    throw new KeyNotFoundException();
                }
                set
                {
                    int index = IndexOfKey(key);
                    if (index >= 0)
                        values[index] = value;
                    else
                        Add(key, value);
                }
            }

            public bool Remove(TKey key)
            {
                int index = IndexOfKey(key);
                if (index < 0) return false;

                // Shift elements to fill the gap
                for (int i = index; i < count - 1; i++)
                {
                    keys[i] = keys[i + 1];
                    values[i] = values[i + 1];
                }

                count--;
                keys[count] = default;
                values[count] = default;
                return true;
            }

            private int IndexOfKey(TKey key)
            {
                if (key == null)
                    throw new ArgumentNullException(nameof(key));

                int left = 0;
                int right = count - 1;

                while (left <= right)
                {
                    int middle = (left + right) / 2;
                    int comparison = keys[middle].CompareTo(key);

                    if (comparison == 0)
                        return middle;
                    if (comparison < 0)
                        left = middle + 1;
                    else
                        right = middle - 1;
                }

                return -1;
            }

            public IEnumerator<KeyValuePair<TKey, TValue>> GetEnumerator()
            {
                for (int i = 0; i < count; i++)
                {
                    yield return new KeyValuePair<TKey, TValue>(keys[i], values[i]);
                }
            }

            IEnumerator IEnumerable.GetEnumerator()
            {
                return GetEnumerator();
            }
        }
        public partial class Form1 : Form
        {
            //private Dictionary<string, string> phoneBook = new Dictionary<string, string>();              //dictionary
            //private SortedList<string, string> phoneBook = new SortedList<string, string>();            //rewrite using sorted list
            private CustomSortedList<string, string> phoneBook = new CustomSortedList<string, string>();    //custom sorted list


            private TextBox txtName;
            private TextBox txtPhone;
            private TextBox txtSearch;
            private Button btnLoad;
            private Button btnLoadDefault;
            private Button btnSearch;
            private Button btnAdd;
            private ListBox listBoxEntries;
            private Label lblResults;

            //file path here
            private string defaultFilePath = Path.Combine(Application.StartupPath, "phonebook.txt");

            public Form1()
            {
                InitializeComponent();
                SetupUI();
            }

            private void InitializeComponent()
            {
                this.Text = "Phone Directory";
                this.Size = new System.Drawing.Size(500, 400);
            }

            private void SetupUI()
            {
                // create and configure UI controls
                txtName = new TextBox { Location = new System.Drawing.Point(20, 20), Size = new System.Drawing.Size(150, 20) };
                txtPhone = new TextBox { Location = new System.Drawing.Point(180, 20), Size = new System.Drawing.Size(150, 20) };
                txtSearch = new TextBox { Location = new System.Drawing.Point(20, 60), Size = new System.Drawing.Size(150, 20) };

                btnLoad = new Button { Text = "Load File", Location = new System.Drawing.Point(340, 20), Size = new System.Drawing.Size(100, 23) };
                //btnLoadDefault = new Button { Text = "Load Default", Location = new System.Drawing.Point(340, 50), Size = new System.Drawing.Size(100, 23) };
                btnSearch = new Button { Text = "Search Phone", Location = new System.Drawing.Point(180, 60), Size = new System.Drawing.Size(100, 23) };
                btnAdd = new Button { Text = "Add Entry", Location = new System.Drawing.Point(340, 60), Size = new System.Drawing.Size(100, 23) };

                listBoxEntries = new ListBox { Location = new System.Drawing.Point(20, 100), Size = new System.Drawing.Size(440, 200) };
                lblResults = new Label { Location = new System.Drawing.Point(20, 310), Size = new System.Drawing.Size(440, 40) };

                // add controls to form
                this.Controls.AddRange(new Control[] {
                txtName, txtPhone, txtSearch, btnLoad, btnLoadDefault, btnSearch, btnAdd, listBoxEntries, lblResults
            });

                // wire up event handlers
                btnLoad.Click += BtnLoad_Click;
                //btnLoadDefault.Click += BtnLoadDefault_Click;
                btnSearch.Click += BtnSearch_Click;
                btnAdd.Click += BtnAdd_Click;
            }

            /*private void BtnLoadDefault_Click(object sender, EventArgs e)
            {
                if (File.Exists(defaultFilePath))
                {
                    LoadPhoneBook(defaultFilePath);
                    DisplayEntries();
                }
                else
                {
                    MessageBox.Show($"Default phone book not found at:\n{defaultFilePath}\n\nPlease create the file or use 'Load File' to select a different file.");
                }
            }*/

            //-------------Load Default does not work-------------------------//

            private void BtnAdd_Click(object sender, EventArgs e)
            {
                string name = txtName.Text.Trim();
                string phone = txtPhone.Text.Trim();

                if (string.IsNullOrEmpty(name) || string.IsNullOrEmpty(phone))
                {
                    MessageBox.Show("Please enter both name and phone number.");
                    return;
                }

                try
                {
                    phoneBook[name] = phone; //update if name exists, add if it doesn't
                    DisplayEntries();
                    txtName.Clear();
                    txtPhone.Clear();
                    lblResults.Text = "Entry added successfully.";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error adding entry: {ex.Message}");
                }
            }
            private void BtnLoad_Click(object sender, EventArgs e)
            {
                OpenFileDialog openFileDialog = new OpenFileDialog
                {
                    Filter = "Text files (*.txt)|*.txt|All files (*.*)|*.*"
                };

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    LoadPhoneBook(openFileDialog.FileName);
                    DisplayEntries();
                }
            }

            private void LoadPhoneBook(string filePath)
            {
                phoneBook.Clear();
                try
                {
                    string[] lines = File.ReadAllLines(filePath);
                    foreach (string line in lines)
                    {
                        string[] parts = line.Split(',');
                        if (parts.Length == 2)
                        {
                            string name = parts[0].Trim();
                            string phone = parts[1].Trim();
                            phoneBook[name] = phone;
                        }
                    }
                    lblResults.Text = $"Successfully loaded {phoneBook.Count} entries.";
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Error loading file: {ex.Message}");
                }
            }

            private void DisplayEntries()
            {
                listBoxEntries.Items.Clear();
                foreach (var entry in phoneBook)
                {
                    listBoxEntries.Items.Add($"{entry.Key}: {entry.Value}");
                }
            }

            private void BtnSearch_Click(object sender, EventArgs e)
            {
                string searchPhone = txtSearch.Text.Trim();
                string result = ReverseLookup(searchPhone);
                //string result = LookupPhoneByName(searchPhone);
                lblResults.Text = result != null
                    ? $"Found: {result}"
                    : "No matching phone number found";
            }

            private string ReverseLookup(string phoneNumber)
            {
                foreach (var entry in phoneBook)
                {
                    if (entry.Value == phoneNumber)
                        return entry.Key;
                }
                return null;
            }

            private string LookupPhoneByName(string name)  //do the opposite of the above function because why not
            {
                if (phoneBook.ContainsKey(name)) { return phoneBook[name]; }
                return null;
            }

        }
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new Form1());
        }
    }
}
