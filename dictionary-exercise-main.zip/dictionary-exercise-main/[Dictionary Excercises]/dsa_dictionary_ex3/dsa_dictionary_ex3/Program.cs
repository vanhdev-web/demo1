﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace dsa_dictionary_ex3
{
    internal class Program
    {
        public class LetterCounter
        {
            private Dictionary<char, int> letterCounts;

            public LetterCounter()
            {
                letterCounts = new Dictionary<char, int>();
            }

            public void CountLetters(string text)
            {
                // Clear previous counts
                letterCounts.Clear();

                // Convert to lower case
                string cleanText = text.ToLower();

                // Count occurrences of each letter
                foreach (char letter in cleanText)
                {
                    // Only count alphabetic characters
                    if (char.IsLetter(letter))
                    {
                        if (letterCounts.ContainsKey(letter))
                        {
                            letterCounts[letter]++;
                        }
                        else
                        {
                            letterCounts.Add(letter, 1);
                        }
                    }
                }
            }

            public void DisplayLetterCounts()
            {
                Console.WriteLine("\nLetter Occurrence Count:");
                Console.WriteLine("======================");

                // Sort the dictionary by letter
                var sortedCounts = letterCounts.OrderBy(x => x.Key);

                foreach (var pair in sortedCounts)
                {
                    Console.WriteLine($"'{pair.Key}' occurs {pair.Value} time(s)");
                }

                Console.WriteLine($"\nTotal letters: {letterCounts.Values.Sum()}");
                Console.WriteLine($"Unique letters: {letterCounts.Count}");
            }
            public class WordCounter
            {
                private Dictionary<string, int> wordCounts;

                public WordCounter()
                {
                    wordCounts = new Dictionary<string, int>();
                }

                public void CountWords(string sentence)
                {
                    // Clear previous counts
                    wordCounts.Clear();

                    // Split the sentence into words and convert to lower case
                    string[] words = sentence.ToLower()
                        .Split(new char[] { ' ', '.', ',', '!', '?', ';', ':', '\t', '\n' },
                        StringSplitOptions.RemoveEmptyEntries);

                    // Count occurrences of each word
                    foreach (string word in words)
                    {
                        if (wordCounts.ContainsKey(word))
                        {
                            wordCounts[word]++;
                        }
                        else
                        {
                            wordCounts.Add(word, 1);
                        }
                    }
                }

                public void DisplayWordCounts()
                {
                    Console.WriteLine("\nWord Occurrence Count:");
                    Console.WriteLine("=====================");

                    // Sort the dictionary by word (key) for better readability
                    var sortedCounts = wordCounts.OrderBy(x => x.Key);

                    foreach (var pair in sortedCounts)
                    {
                        Console.WriteLine($"'{pair.Key}' occurs {pair.Value} time(s)");
                    }

                    Console.WriteLine($"\nTotal unique words: {wordCounts.Count}");
                }
            }
            static void Main(string[] args)
            {
                /*WordCounter counter = new WordCounter();

                Console.WriteLine("Enter a sentence:");
                string sentence = Console.ReadLine();

                counter.CountWords(sentence);
                counter.DisplayWordCounts();

                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();*/

                LetterCounter counter = new LetterCounter();

                Console.WriteLine("Enter a sentence:");
                string sentence = Console.ReadLine();

                counter.CountLetters(sentence);
                counter.DisplayLetterCounts();

                Console.WriteLine("\nPress any key to exit...");
                Console.ReadKey();
            }
        }
    }
}
